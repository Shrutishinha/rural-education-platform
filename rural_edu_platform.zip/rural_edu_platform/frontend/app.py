import streamlit as st
import api_client as api
from student_view import render_student_view
from teacher_view import render_teacher_view

st.set_page_config(
    page_title="Rural Digital Learning Platform",
    page_icon="🎓",
    layout="wide",
)

if "token" not in st.session_state:
    st.session_state.token = None
    st.session_state.user = None


def render_login():
    st.markdown("<h1 style='text-align:center;'>🎓 Digital Learning Platform</h1>", unsafe_allow_html=True)
    st.markdown(
        "<p style='text-align:center; color:gray;'>Bringing quality education to every classroom — "
        "built for low-bandwidth, rural connectivity.</p>",
        unsafe_allow_html=True,
    )

    _, col, _ = st.columns([1, 2, 1])
    with col:
        tab_login, tab_register = st.tabs(["🔑 Login", "🆕 Register"])

        with tab_login:
            with st.form("login_form"):
                username = st.text_input("Username")
                password = st.text_input("Password", type="password")
                submitted = st.form_submit_button("Login", type="primary", use_container_width=True)
            if submitted:
                try:
                    result = api.login(username, password)
                    st.session_state.token = result["access_token"]
                    st.session_state.user = result["user"]
                    st.rerun()
                except RuntimeError as e:
                    st.error(f"Login failed: {e}")
            st.caption("Demo accounts — Teacher: teacher1/teacher123 · Student: student1/student123")

        with tab_register:
            with st.form("register_form"):
                full_name = st.text_input("Full Name")
                username = st.text_input("Choose a Username")
                password = st.text_input("Choose a Password", type="password")
                role = st.selectbox("I am a...", ["student", "teacher"])
                grade_level = st.text_input("Grade Level (students only, e.g. 'Grade 6')")
                school_name = st.text_input("School Name")
                submitted = st.form_submit_button("Create Account", type="primary", use_container_width=True)
            if submitted:
                if not username or not password or not full_name:
                    st.error("Please fill in all required fields.")
                else:
                    try:
                        result = api.register(
                            username, password, full_name, role,
                            grade_level=grade_level or None, school_name=school_name or None,
                        )
                        st.session_state.token = result["access_token"]
                        st.session_state.user = result["user"]
                        st.success("Account created!")
                        st.rerun()
                    except RuntimeError as e:
                        st.error(f"Registration failed: {e}")


def render_app():
    user = st.session_state.user
    with st.sidebar:
        if st.button("🚪 Log out"):
            st.session_state.token = None
            st.session_state.user = None
            st.rerun()
        st.markdown("---")

    if user["role"] == "teacher":
        render_teacher_view(user)
    else:
        render_student_view(user)


if st.session_state.token is None:
    render_login()
else:
    render_app()
