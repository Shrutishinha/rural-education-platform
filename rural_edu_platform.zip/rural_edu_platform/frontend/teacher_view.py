import streamlit as st
import pandas as pd
import api_client as api


def render_teacher_view(user):
    st.sidebar.markdown(f"### 👩‍🏫 {user['full_name']}")
    st.sidebar.caption(user.get("school_name") or "")
    page = st.sidebar.radio(
        "Navigate", ["Class Dashboard", "Manage Courses", "Add Lesson", "Add Quiz"],
        label_visibility="collapsed",
    )

    if page == "Class Dashboard":
        _render_dashboard()
    elif page == "Manage Courses":
        _render_manage_courses()
    elif page == "Add Lesson":
        _render_add_lesson()
    else:
        _render_add_quiz()


def _render_dashboard():
    st.title("📊 Class Dashboard")

    grade_filter = st.text_input("Filter by grade level (optional, e.g. 'Grade 6')")

    try:
        summary = api.class_summary(grade_level=grade_filter or None)
    except RuntimeError as e:
        st.error(f"Could not load class summary: {e}")
        return

    if not summary:
        st.info("No students found yet.")
        return

    df = pd.DataFrame(summary)
    df["completion_pct"] = (df["lessons_completed"] / df["total_lessons"].replace(0, 1) * 100).round(0)

    col1, col2, col3 = st.columns(3)
    col1.metric("Students", len(df))
    col2.metric("Avg. Lesson Completion", f"{df['completion_pct'].mean():.0f}%")
    col3.metric("Avg. Quiz Score", f"{df['average_quiz_score'].mean():.0f}%")

    st.markdown("---")
    st.subheader("Student Details")
    display_df = df.rename(columns={
        "full_name": "Name", "grade_level": "Grade", "lessons_completed": "Lessons Done",
        "total_lessons": "Total Lessons", "quizzes_taken": "Quizzes Taken",
        "average_quiz_score": "Avg Quiz %", "completion_pct": "Completion %",
    })[["Name", "Grade", "Lessons Done", "Total Lessons", "Quizzes Taken", "Avg Quiz %", "Completion %"]]
    st.dataframe(display_df, use_container_width=True, hide_index=True)

    st.markdown("---")
    st.subheader("Lesson Completion by Student")
    st.bar_chart(df.set_index("full_name")["completion_pct"])

    st.subheader("Average Quiz Score by Student")
    st.bar_chart(df.set_index("full_name")["average_quiz_score"])


def _render_manage_courses():
    st.title("📁 Manage Courses")

    with st.expander("➕ Create a new course"):
        with st.form("new_course_form"):
            title = st.text_input("Course Title")
            subject = st.text_input("Subject")
            grade_level = st.text_input("Grade Level (e.g. 'Grade 6')")
            description = st.text_area("Description")
            submitted = st.form_submit_button("Create Course", type="primary")
        if submitted:
            if not title:
                st.error("Title is required.")
            else:
                try:
                    api.create_course(title, description, subject, grade_level)
                    st.success(f"Course '{title}' created!")
                    st.rerun()
                except RuntimeError as e:
                    st.error(str(e))

    st.markdown("---")
    st.subheader("Existing Courses")
    try:
        courses = api.list_courses()
    except RuntimeError as e:
        st.error(f"Could not load courses: {e}")
        return

    if not courses:
        st.info("No courses yet — create one above.")
        return

    for c in courses:
        with st.container(border=True):
            col1, col2 = st.columns([4, 1])
            with col1:
                st.markdown(f"**{c['title']}** — {c.get('subject') or 'General'} · {c.get('grade_level') or 'All grades'}")
                st.caption(c.get("description") or "")
                st.caption(f"{c['lesson_count']} lesson(s)")
            with col2:
                if st.button("🗑️ Delete", key=f"del_{c['id']}"):
                    try:
                        api.delete_course(c["id"])
                        st.success("Deleted")
                        st.rerun()
                    except RuntimeError as e:
                        st.error(str(e))


def _render_add_lesson():
    st.title("➕ Add a Lesson")

    try:
        courses = api.list_courses()
    except RuntimeError as e:
        st.error(f"Could not load courses: {e}")
        return

    if not courses:
        st.info("Create a course first under 'Manage Courses'.")
        return

    course_titles = {c["title"]: c for c in courses}
    selected = st.selectbox("Select course", list(course_titles.keys()))
    course = course_titles[selected]

    with st.form("new_lesson_form"):
        title = st.text_input("Lesson Title")
        content = st.text_area(
            "Lesson Content (Markdown supported — keep it text-based for low-bandwidth access)",
            height=250,
            placeholder="# Lesson Title\n\nExplain the concept here...",
        )
        video_url = st.text_input("Optional video URL (leave blank for offline/low-bandwidth friendliness)")
        order_index = st.number_input("Order in course", min_value=1, value=1, step=1)
        estimated_minutes = st.number_input("Estimated minutes", min_value=1, value=15, step=5)
        submitted = st.form_submit_button("Add Lesson", type="primary")

    if submitted:
        if not title or not content:
            st.error("Title and content are required.")
        else:
            try:
                api.create_lesson(course["id"], title, content, video_url or None, int(order_index), int(estimated_minutes))
                st.success(f"Lesson '{title}' added to {course['title']}!")
            except RuntimeError as e:
                st.error(str(e))


def _render_add_quiz():
    st.title("➕ Add a Quiz to a Lesson")

    try:
        courses = api.list_courses()
    except RuntimeError as e:
        st.error(f"Could not load courses: {e}")
        return
    if not courses:
        st.info("Create a course and lesson first.")
        return

    course_titles = {c["title"]: c for c in courses}
    selected_course = st.selectbox("Select course", list(course_titles.keys()))
    course = course_titles[selected_course]

    try:
        lessons = api.list_lessons(course["id"])
    except RuntimeError as e:
        st.error(f"Could not load lessons: {e}")
        return
    if not lessons:
        st.info("This course has no lessons yet.")
        return

    available = [l for l in lessons if not l.get("has_quiz")]
    if not available:
        st.info("All lessons in this course already have quizzes.")
        return

    lesson_titles = {l["title"]: l for l in available}
    selected_lesson_title = st.selectbox("Select lesson", list(lesson_titles.keys()))
    lesson = lesson_titles[selected_lesson_title]

    num_questions = st.number_input("Number of questions", min_value=1, max_value=20, value=3, step=1)
    quiz_title = st.text_input("Quiz Title", value=f"{lesson['title']} Quiz")
    pass_pct = st.slider("Pass percentage", min_value=0, max_value=100, value=60)

    questions = []
    with st.form("new_quiz_form"):
        for i in range(int(num_questions)):
            st.markdown(f"**Question {i+1}**")
            qtext = st.text_input(f"Question text {i+1}", key=f"qtext_{i}")
            a = st.text_input(f"Option A {i+1}", key=f"a_{i}")
            b = st.text_input(f"Option B {i+1}", key=f"b_{i}")
            c = st.text_input(f"Option C {i+1}", key=f"c_{i}")
            d = st.text_input(f"Option D {i+1}", key=f"d_{i}")
            correct = st.selectbox(f"Correct option {i+1}", ["a", "b", "c", "d"], key=f"correct_{i}")
            questions.append({
                "question_text": qtext, "option_a": a, "option_b": b,
                "option_c": c, "option_d": d, "correct_option": correct, "points": 1,
            })
            st.markdown("---")
        submitted = st.form_submit_button("Create Quiz", type="primary")

    if submitted:
        if any(not q["question_text"] or not q["option_a"] or not q["option_b"] for q in questions):
            st.error("Please fill in all question fields.")
        else:
            try:
                api.create_quiz(lesson["id"], quiz_title, pass_pct, questions)
                st.success(f"Quiz '{quiz_title}' created for lesson '{lesson['title']}'!")
            except RuntimeError as e:
                st.error(str(e))
