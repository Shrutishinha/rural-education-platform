import streamlit as st
import pandas as pd
import api_client as api


def render_student_view(user):
    st.sidebar.markdown(f"### 👋 Hi, {user['full_name']}")
    st.sidebar.caption(f"Grade: {user.get('grade_level', 'N/A')}")
    page = st.sidebar.radio("Navigate", ["My Courses", "My Progress"], label_visibility="collapsed")

    if page == "My Courses":
        _render_courses(user)
    else:
        _render_progress(user)


def _render_courses(user):
    st.title("📚 My Courses")

    low_bandwidth = st.toggle("📶 Low-bandwidth mode (hide videos, text only)", value=False)

    try:
        courses = api.list_courses(grade_level=user.get("grade_level"))
    except RuntimeError as e:
        st.error(f"Could not load courses: {e}")
        return

    if not courses:
        st.info("No courses available yet for your grade level. Check back soon!")
        return

    course_titles = {f"{c['title']} ({c['subject'] or 'General'})": c for c in courses}
    selected_label = st.selectbox("Choose a course", list(course_titles.keys()))
    course = course_titles[selected_label]

    if course.get("description"):
        st.caption(course["description"])

    try:
        lessons = api.list_lessons(course["id"])
    except RuntimeError as e:
        st.error(f"Could not load lessons: {e}")
        return

    if not lessons:
        st.info("This course has no lessons yet.")
        return

    try:
        progress_records = {p["lesson_id"]: p["completed"] for p in api.my_progress_for_course(course["id"])}
    except RuntimeError:
        progress_records = {}

    lesson_labels = []
    for l in lessons:
        done = "✅" if progress_records.get(l["id"]) else "⬜"
        lesson_labels.append(f"{done} {l['order_index']}. {l['title']} (~{l['estimated_minutes']} min)")

    idx = st.radio("Lessons", range(len(lessons)), format_func=lambda i: lesson_labels[i])
    lesson = lessons[idx]

    st.markdown("---")
    st.subheader(lesson["title"])
    st.markdown(lesson["content_text"])

    if lesson.get("video_url") and not low_bandwidth:
        st.video(lesson["video_url"])
    elif lesson.get("video_url") and low_bandwidth:
        st.caption("🎥 Video available — disable low-bandwidth mode to watch.")

    already_done = progress_records.get(lesson["id"], False)
    col1, col2 = st.columns([1, 3])
    with col1:
        if not already_done:
            if st.button("✅ Mark as Complete", type="primary"):
                try:
                    api.mark_progress(lesson["id"], True)
                    st.success("Marked complete!")
                    st.rerun()
                except RuntimeError as e:
                    st.error(str(e))
        else:
            st.success("Completed")

    if lesson.get("has_quiz"):
        st.markdown("---")
        _render_quiz(lesson)


def _render_quiz(lesson):
    st.subheader(f"📝 Quiz: {lesson['title']}")
    try:
        quiz = api.get_quiz_by_lesson(lesson["id"])
    except RuntimeError as e:
        st.error(f"Could not load quiz: {e}")
        return
    if not quiz:
        return

    try:
        past_attempts = api.my_attempts(quiz["id"])
    except RuntimeError:
        past_attempts = []

    if past_attempts:
        best = max(a["percentage"] for a in past_attempts)
        st.caption(f"Your best score so far: {best:.0f}% ({len(past_attempts)} attempt(s))")

    with st.form(key=f"quiz_form_{quiz['id']}"):
        answers = {}
        for q in quiz["questions"]:
            st.markdown(f"**{q['question_text']}**")
            options = {
                "a": q["option_a"], "b": q["option_b"],
                "c": q["option_c"], "d": q["option_d"],
            }
            choice = st.radio(
                "Select one:", list(options.keys()),
                format_func=lambda k: f"{k.upper()}. {options[k]}",
                key=f"q_{q['id']}", label_visibility="collapsed",
            )
            answers[str(q["id"])] = choice

        submitted = st.form_submit_button("Submit Quiz", type="primary")

    if submitted:
        try:
            result = api.submit_quiz(quiz["id"], answers)
            if result["passed"]:
                st.success(f"🎉 You passed! Score: {result['percentage']:.0f}% ({result['score']:.0f}/{result['total_points']:.0f})")
                st.balloons()
            else:
                st.warning(f"Score: {result['percentage']:.0f}% ({result['score']:.0f}/{result['total_points']:.0f}). Needed {quiz['pass_percentage']:.0f}% to pass — try again!")
        except RuntimeError as e:
            st.error(str(e))


def _render_progress(user):
    st.title("📊 My Progress")

    try:
        courses = api.list_courses(grade_level=user.get("grade_level"))
    except RuntimeError as e:
        st.error(f"Could not load courses: {e}")
        return

    if not courses:
        st.info("No courses to show progress for yet.")
        return

    rows = []
    for c in courses:
        try:
            lessons = api.list_lessons(c["id"])
            progress = api.my_progress_for_course(c["id"])
            completed = sum(1 for p in progress if p["completed"])
        except RuntimeError:
            lessons, completed = [], 0
        total = len(lessons)
        pct = (completed / total * 100) if total else 0
        rows.append({"Course": c["title"], "Completed": completed, "Total Lessons": total, "Progress %": round(pct, 0)})

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)

    for _, row in df.iterrows():
        st.progress(row["Progress %"] / 100, text=f"{row['Course']}: {row['Progress %']:.0f}%")
