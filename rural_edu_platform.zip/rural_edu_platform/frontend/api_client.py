import os
import requests
import streamlit as st

API_BASE_URL = os.environ.get("EDU_API_BASE_URL", "http://localhost:8000")


def _headers():
    token = st.session_state.get("token")
    if token:
        return {"Authorization": f"Bearer {token}"}
    return {}


def _handle(resp):
    if resp.status_code >= 400:
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        raise RuntimeError(detail)
    return resp.json()


# ---------- Auth ----------

def register(username, password, full_name, role, grade_level=None, school_name=None):
    resp = requests.post(f"{API_BASE_URL}/auth/register", json={
        "username": username, "password": password, "full_name": full_name,
        "role": role, "grade_level": grade_level, "school_name": school_name,
    }, timeout=10)
    return _handle(resp)


def login(username, password):
    resp = requests.post(f"{API_BASE_URL}/auth/login", json={
        "username": username, "password": password,
    }, timeout=10)
    return _handle(resp)


# ---------- Courses / Lessons ----------

def list_courses(grade_level=None):
    params = {"grade_level": grade_level} if grade_level else {}
    resp = requests.get(f"{API_BASE_URL}/courses", headers=_headers(), params=params, timeout=10)
    return _handle(resp)


def create_course(title, description, subject, grade_level):
    resp = requests.post(f"{API_BASE_URL}/courses", headers=_headers(), json={
        "title": title, "description": description, "subject": subject, "grade_level": grade_level,
    }, timeout=10)
    return _handle(resp)


def delete_course(course_id):
    resp = requests.delete(f"{API_BASE_URL}/courses/{course_id}", headers=_headers(), timeout=10)
    return _handle(resp)


def list_lessons(course_id):
    resp = requests.get(f"{API_BASE_URL}/courses/{course_id}/lessons", headers=_headers(), timeout=10)
    return _handle(resp)


def create_lesson(course_id, title, content_text, video_url, order_index, estimated_minutes):
    resp = requests.post(f"{API_BASE_URL}/courses/{course_id}/lessons", headers=_headers(), json={
        "title": title, "content_text": content_text, "video_url": video_url,
        "order_index": order_index, "estimated_minutes": estimated_minutes,
    }, timeout=10)
    return _handle(resp)


def get_lesson(lesson_id):
    resp = requests.get(f"{API_BASE_URL}/lessons/{lesson_id}", headers=_headers(), timeout=10)
    return _handle(resp)


# ---------- Quizzes ----------

def create_quiz(lesson_id, title, pass_percentage, questions):
    resp = requests.post(f"{API_BASE_URL}/quizzes", headers=_headers(), json={
        "lesson_id": lesson_id, "title": title, "pass_percentage": pass_percentage,
        "questions": questions,
    }, timeout=10)
    return _handle(resp)


def get_quiz_by_lesson(lesson_id):
    resp = requests.get(f"{API_BASE_URL}/quizzes/by-lesson/{lesson_id}", headers=_headers(), timeout=10)
    if resp.status_code == 404:
        return None
    return _handle(resp)


def submit_quiz(quiz_id, answers):
    resp = requests.post(f"{API_BASE_URL}/quizzes/{quiz_id}/submit", headers=_headers(), json={
        "answers": answers,
    }, timeout=10)
    return _handle(resp)


def my_attempts(quiz_id):
    resp = requests.get(f"{API_BASE_URL}/quizzes/{quiz_id}/my-attempts", headers=_headers(), timeout=10)
    return _handle(resp)


# ---------- Progress ----------

def mark_progress(lesson_id, completed=True):
    resp = requests.post(f"{API_BASE_URL}/progress/mark", headers=_headers(), json={
        "lesson_id": lesson_id, "completed": completed,
    }, timeout=10)
    return _handle(resp)


def my_progress_for_course(course_id):
    resp = requests.get(f"{API_BASE_URL}/progress/my-progress/{course_id}", headers=_headers(), timeout=10)
    return _handle(resp)


def class_summary(grade_level=None):
    params = {"grade_level": grade_level} if grade_level else {}
    resp = requests.get(f"{API_BASE_URL}/progress/class-summary", headers=_headers(), params=params, timeout=10)
    return _handle(resp)
