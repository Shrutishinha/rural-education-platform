# Digital Learning Platform for Rural Schools

A full-stack learning platform built for low-bandwidth, rural school environments.

**Stack:** Streamlit (frontend) + FastAPI (backend) + SQLite (database)

## Features
- **Student side:** browse courses/lessons (markdown text, works with no video/low bandwidth), mark lessons complete, take auto-graded quizzes, see personal progress
- **Teacher side:** create courses & lessons, build quizzes, view a class dashboard (completion %, average quiz scores, per-student breakdown, charts)
- **Low-bandwidth mode:** a toggle on the student side hides videos so pages load fast on slow connections; all lesson content is plain text/markdown by default
- **Auth:** simple username/password with role (student/teacher), token stored for the session

## Project structure
```
rural_edu_platform/
├── backend/            FastAPI app
│   ├── main.py          entrypoint
│   ├── models.py        DB tables (SQLAlchemy)
│   ├── schemas.py       request/response validation
│   ├── auth.py          password hashing + tokens
│   ├── deps.py          auth dependencies (current user, require_teacher)
│   ├── seed.py          demo data loader
│   └── routers/         users, courses, quizzes, progress
└── frontend/            Streamlit app
    ├── app.py            entrypoint (login/register + routing)
    ├── api_client.py     talks to the FastAPI backend
    ├── student_view.py
    └── teacher_view.py
```

## Running it locally

**1. Backend**
```bash
cd backend
pip install -r requirements.txt
python seed.py          # creates demo accounts + a sample Grade 6 Math course
uvicorn main:app --reload --port 8000
```

**2. Frontend** (in a new terminal)
```bash
cd frontend
pip install -r requirements.txt
streamlit run app.py
```

Open the URL Streamlit prints (usually `http://localhost:8501`).

## Demo accounts (created by `seed.py`)
| Role    | Username  | Password    |
|---------|-----------|-------------|
| Teacher | teacher1  | teacher123  |
| Student | student1  | student123  |
| Student | student2  | student123  |
| Student | student3  | student123  |

The seed data includes one course ("Mathematics - Grade 6") with 3 lessons and one quiz, so you can log in and see it working immediately. You can also register new accounts from the login screen.

## Deploying for real use
- **Backend:** any host that runs Python (Render, Railway, a college server, even a Raspberry Pi on the school LAN). SQLite is fine for a single school; swap to Postgres in `database.py` if you outgrow it.
- **Frontend:** Streamlit Community Cloud (free) or the same host as the backend. Set the environment variable `EDU_API_BASE_URL` to point at wherever the backend is running, e.g.:
  ```bash
  export EDU_API_BASE_URL=https://your-backend-url.com
  ```
- For a real rural deployment, the backend could run on a local server/router at the school (no internet needed) so students access it over the school's local Wi-Fi only — content stays offline-friendly since lessons are plain markdown text.

## Notes / things to harden before a real rollout
- Passwords are hashed but tokens use a simple custom JWT-like scheme — for production, swap in `python-jose` or `PyJWT` with a securely stored secret (set `EDU_PLATFORM_SECRET` env var either way).
- Add rate limiting / HTTPS if exposed to the public internet.
- Add bulk student import (CSV) for teachers instead of one-by-one registration.
- Add file/image upload for lessons if you want richer content beyond text+optional video link.
