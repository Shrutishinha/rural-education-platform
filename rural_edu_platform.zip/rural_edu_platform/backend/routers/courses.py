from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
import models
import schemas
from deps import get_current_user, require_teacher

router = APIRouter(tags=["courses"])


@router.post("/courses", response_model=schemas.CourseOut)
def create_course(
    course_in: schemas.CourseCreate,
    db: Session = Depends(get_db),
    teacher: models.User = Depends(require_teacher),
):
    course = models.Course(
        title=course_in.title,
        description=course_in.description,
        subject=course_in.subject,
        grade_level=course_in.grade_level,
        created_by=teacher.id,
    )
    db.add(course)
    db.commit()
    db.refresh(course)
    out = schemas.CourseOut.model_validate(course)
    out.lesson_count = 0
    return out


@router.get("/courses", response_model=List[schemas.CourseOut])
def list_courses(
    grade_level: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    q = db.query(models.Course)
    if grade_level:
        q = q.filter(models.Course.grade_level == grade_level)
    courses = q.all()
    results = []
    for c in courses:
        out = schemas.CourseOut.model_validate(c)
        out.lesson_count = len(c.lessons)
        results.append(out)
    return results


@router.get("/courses/{course_id}/lessons", response_model=List[schemas.LessonOut])
def list_lessons(
    course_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    course = db.query(models.Course).filter(models.Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    results = []
    for lesson in course.lessons:
        out = schemas.LessonOut.model_validate(lesson)
        out.has_quiz = lesson.quiz is not None
        results.append(out)
    return results


@router.post("/courses/{course_id}/lessons", response_model=schemas.LessonOut)
def create_lesson(
    course_id: int,
    lesson_in: schemas.LessonCreate,
    db: Session = Depends(get_db),
    teacher: models.User = Depends(require_teacher),
):
    course = db.query(models.Course).filter(models.Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    lesson = models.Lesson(
        course_id=course_id,
        title=lesson_in.title,
        content_text=lesson_in.content_text,
        video_url=lesson_in.video_url,
        order_index=lesson_in.order_index,
        estimated_minutes=lesson_in.estimated_minutes,
    )
    db.add(lesson)
    db.commit()
    db.refresh(lesson)
    out = schemas.LessonOut.model_validate(lesson)
    out.has_quiz = False
    return out


@router.get("/lessons/{lesson_id}", response_model=schemas.LessonOut)
def get_lesson(
    lesson_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    lesson = db.query(models.Lesson).filter(models.Lesson.id == lesson_id).first()
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")
    out = schemas.LessonOut.model_validate(lesson)
    out.has_quiz = lesson.quiz is not None
    return out


@router.delete("/courses/{course_id}")
def delete_course(
    course_id: int,
    db: Session = Depends(get_db),
    teacher: models.User = Depends(require_teacher),
):
    course = db.query(models.Course).filter(models.Course.id == course_id).first()
    if not course:
        raise HTTPException(status_code=404, detail="Course not found")
    db.delete(course)
    db.commit()
    return {"detail": "deleted"}
