from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
import models
import schemas
from deps import get_current_user, require_teacher

router = APIRouter(prefix="/progress", tags=["progress"])


@router.post("/mark", response_model=schemas.ProgressOut)
def mark_progress(
    update: schemas.ProgressUpdate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    lesson = db.query(models.Lesson).filter(models.Lesson.id == update.lesson_id).first()
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")

    record = (
        db.query(models.Progress)
        .filter(
            models.Progress.student_id == current_user.id,
            models.Progress.lesson_id == update.lesson_id,
        )
        .first()
    )
    if not record:
        record = models.Progress(student_id=current_user.id, lesson_id=update.lesson_id)
        db.add(record)

    record.completed = update.completed
    record.completed_at = datetime.utcnow() if update.completed else None
    db.commit()
    db.refresh(record)
    return record


@router.get("/my-progress/{course_id}", response_model=List[schemas.ProgressOut])
def my_progress_for_course(
    course_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    lesson_ids = [l.id for l in db.query(models.Lesson).filter(models.Lesson.course_id == course_id).all()]
    records = (
        db.query(models.Progress)
        .filter(
            models.Progress.student_id == current_user.id,
            models.Progress.lesson_id.in_(lesson_ids),
        )
        .all()
    )
    return records


@router.get("/class-summary", response_model=List[schemas.StudentSummary])
def class_summary(
    grade_level: Optional[str] = None,
    db: Session = Depends(get_db),
    teacher: models.User = Depends(require_teacher),
):
    q = db.query(models.User).filter(models.User.role == models.RoleEnum.student)
    if grade_level:
        q = q.filter(models.User.grade_level == grade_level)
    students = q.all()

    total_lessons = db.query(models.Lesson).count()

    results = []
    for student in students:
        completed = (
            db.query(models.Progress)
            .filter(models.Progress.student_id == student.id, models.Progress.completed == True)  # noqa: E712
            .count()
        )
        attempts = (
            db.query(models.QuizAttempt)
            .filter(models.QuizAttempt.student_id == student.id)
            .all()
        )
        avg_score = (
            sum(a.percentage for a in attempts) / len(attempts) if attempts else 0.0
        )
        results.append(
            schemas.StudentSummary(
                student_id=student.id,
                full_name=student.full_name,
                grade_level=student.grade_level,
                lessons_completed=completed,
                total_lessons=total_lessons,
                quizzes_taken=len(attempts),
                average_quiz_score=round(avg_score, 1),
            )
        )
    return results
