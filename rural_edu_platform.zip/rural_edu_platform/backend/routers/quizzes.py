from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
import models
import schemas
from deps import get_current_user, require_teacher

router = APIRouter(prefix="/quizzes", tags=["quizzes"])


@router.post("", response_model=schemas.QuizOut)
def create_quiz(
    quiz_in: schemas.QuizCreate,
    db: Session = Depends(get_db),
    teacher: models.User = Depends(require_teacher),
):
    lesson = db.query(models.Lesson).filter(models.Lesson.id == quiz_in.lesson_id).first()
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")
    if lesson.quiz is not None:
        raise HTTPException(status_code=400, detail="Lesson already has a quiz")

    quiz = models.Quiz(
        lesson_id=quiz_in.lesson_id,
        title=quiz_in.title,
        pass_percentage=quiz_in.pass_percentage,
    )
    db.add(quiz)
    db.flush()

    for q in quiz_in.questions:
        question = models.Question(
            quiz_id=quiz.id,
            question_text=q.question_text,
            option_a=q.option_a,
            option_b=q.option_b,
            option_c=q.option_c,
            option_d=q.option_d,
            correct_option=q.correct_option.lower(),
            points=q.points,
        )
        db.add(question)

    db.commit()
    db.refresh(quiz)
    return quiz


@router.get("/by-lesson/{lesson_id}", response_model=schemas.QuizOut)
def get_quiz_by_lesson(
    lesson_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    quiz = db.query(models.Quiz).filter(models.Quiz.lesson_id == lesson_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="No quiz for this lesson")
    return quiz


@router.post("/{quiz_id}/submit", response_model=schemas.QuizAttemptOut)
def submit_quiz(
    quiz_id: int,
    submission: schemas.QuizSubmission,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    quiz = db.query(models.Quiz).filter(models.Quiz.id == quiz_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")

    total_points = 0
    score = 0
    for question in quiz.questions:
        total_points += question.points
        given = submission.answers.get(str(question.id))
        if given and given.lower() == question.correct_option:
            score += question.points

    percentage = (score / total_points * 100) if total_points > 0 else 0.0
    passed = percentage >= quiz.pass_percentage

    attempt = models.QuizAttempt(
        quiz_id=quiz_id,
        student_id=current_user.id,
        score=score,
        total_points=total_points,
        percentage=percentage,
        passed=passed,
    )
    db.add(attempt)
    db.commit()
    db.refresh(attempt)
    return attempt


@router.get("/{quiz_id}/my-attempts", response_model=list[schemas.QuizAttemptOut])
def my_attempts(
    quiz_id: int,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(get_current_user),
):
    attempts = (
        db.query(models.QuizAttempt)
        .filter(
            models.QuizAttempt.quiz_id == quiz_id,
            models.QuizAttempt.student_id == current_user.id,
        )
        .order_by(models.QuizAttempt.submitted_at.desc())
        .all()
    )
    return attempts
