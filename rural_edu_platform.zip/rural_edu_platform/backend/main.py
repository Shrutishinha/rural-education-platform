from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import Base, engine
import models  # noqa: F401 (ensures models are registered before create_all)
from routers import users, courses, quizzes, progress

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Rural School Digital Learning Platform API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(users.router)
app.include_router(courses.router)
app.include_router(quizzes.router)
app.include_router(progress.router)


@app.get("/")
def root():
    return {"status": "ok", "message": "Rural Digital Learning Platform API is running"}


@app.get("/health")
def health():
    return {"status": "healthy"}
