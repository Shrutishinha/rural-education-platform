from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel, ConfigDict


# ---------- Auth / Users ----------

class UserCreate(BaseModel):
    username: str
    password: str
    full_name: str
    role: str  # "student" or "teacher"
    grade_level: Optional[str] = None
    school_name: Optional[str] = None


class UserLogin(BaseModel):
    username: str
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    username: str
    full_name: str
    role: str
    grade_level: Optional[str] = None
    school_name: Optional[str] = None


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# ---------- Courses / Lessons ----------

class LessonCreate(BaseModel):
    title: str
    content_text: str
    video_url: Optional[str] = None
    order_index: int = 0
    estimated_minutes: int = 10


class LessonOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    course_id: int
    title: str
    content_text: str
    video_url: Optional[str] = None
    order_index: int
    estimated_minutes: int
    has_quiz: bool = False


class CourseCreate(BaseModel):
    title: str
    description: Optional[str] = None
    subject: Optional[str] = None
    grade_level: Optional[str] = None


class CourseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    title: str
    description: Optional[str] = None
    subject: Optional[str] = None
    grade_level: Optional[str] = None
    lesson_count: int = 0


# ---------- Quizzes ----------

class QuestionCreate(BaseModel):
    question_text: str
    option_a: str
    option_b: str
    option_c: str
    option_d: str
    correct_option: str
    points: int = 1


class QuestionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    question_text: str
    option_a: str
    option_b: str
    option_c: str
    option_d: str
    points: int


class QuestionOutWithAnswer(QuestionOut):
    correct_option: str


class QuizCreate(BaseModel):
    lesson_id: int
    title: str
    pass_percentage: float = 50.0
    questions: List[QuestionCreate]


class QuizOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    lesson_id: int
    title: str
    pass_percentage: float
    questions: List[QuestionOut]


class QuizSubmission(BaseModel):
    answers: dict  # {question_id (str): "a"/"b"/"c"/"d"}


class QuizAttemptOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    quiz_id: int
    score: float
    total_points: float
    percentage: float
    passed: bool
    submitted_at: datetime


# ---------- Progress ----------

class ProgressUpdate(BaseModel):
    lesson_id: int
    completed: bool = True


class ProgressOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    lesson_id: int
    completed: bool
    completed_at: Optional[datetime] = None


class StudentSummary(BaseModel):
    student_id: int
    full_name: str
    grade_level: Optional[str] = None
    lessons_completed: int
    total_lessons: int
    quizzes_taken: int
    average_quiz_score: float
