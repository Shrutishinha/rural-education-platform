"""
Run this once to populate the database with demo data:
    python seed.py

Creates:
  - 1 teacher account (username: teacher1 / password: teacher123)
  - 3 student accounts (student1/2/3, password: student123)
  - 1 course "Mathematics - Grade 6" with 3 lessons, one with a quiz
"""
from database import Base, engine, SessionLocal
import models
from auth import hash_password

Base.metadata.create_all(bind=engine)
db = SessionLocal()

if db.query(models.User).filter(models.User.username == "teacher1").first():
    print("Demo data already exists. Skipping.")
else:
    teacher = models.User(
        username="teacher1",
        hashed_password=hash_password("teacher123"),
        full_name="Mrs. Anjali Sharma",
        role=models.RoleEnum.teacher,
        school_name="Govt. Senior Secondary School, Rewari",
    )
    db.add(teacher)
    db.flush()

    students = []
    for i, name in enumerate(["Ravi Kumar", "Priya Devi", "Amit Singh"], start=1):
        s = models.User(
            username=f"student{i}",
            hashed_password=hash_password("student123"),
            full_name=name,
            role=models.RoleEnum.student,
            grade_level="Grade 6",
            school_name="Govt. Senior Secondary School, Rewari",
        )
        db.add(s)
        students.append(s)
    db.flush()

    course = models.Course(
        title="Mathematics - Grade 6",
        description="Foundational math concepts: fractions, geometry basics, and simple equations.",
        subject="Mathematics",
        grade_level="Grade 6",
        created_by=teacher.id,
    )
    db.add(course)
    db.flush()

    lesson1 = models.Lesson(
        course_id=course.id,
        title="Understanding Fractions",
        content_text=(
            "# Understanding Fractions\n\n"
            "A fraction represents a part of a whole. It has two parts:\n\n"
            "- **Numerator** (top number): how many parts we have\n"
            "- **Denominator** (bottom number): how many equal parts the whole is divided into\n\n"
            "### Example\n"
            "If a roti is cut into 4 equal pieces and you eat 1 piece, you ate 1/4 of the roti.\n\n"
            "### Types of Fractions\n"
            "1. **Proper fraction**: numerator < denominator (e.g. 3/4)\n"
            "2. **Improper fraction**: numerator >= denominator (e.g. 5/4)\n"
            "3. **Mixed number**: whole number + fraction (e.g. 1 1/4)\n\n"
            "Practice: Try dividing a piece of paper into equal parts and shading some of them to represent different fractions."
        ),
        video_url=None,
        order_index=1,
        estimated_minutes=15,
    )
    lesson2 = models.Lesson(
        course_id=course.id,
        title="Basic Shapes and Geometry",
        content_text=(
            "# Basic Shapes and Geometry\n\n"
            "Geometry is the study of shapes, sizes, and space.\n\n"
            "### Common Shapes\n"
            "- **Triangle**: 3 sides, 3 angles\n"
            "- **Square**: 4 equal sides, 4 right angles\n"
            "- **Rectangle**: opposite sides equal, 4 right angles\n"
            "- **Circle**: a round shape with no corners\n\n"
            "### Perimeter and Area\n"
            "- Perimeter is the distance around a shape.\n"
            "- Area is the space inside a shape.\n\n"
            "For a rectangle: Area = length x width, Perimeter = 2 x (length + width)\n\n"
            "Try measuring the length and width of your notebook and calculate its area and perimeter!"
        ),
        video_url=None,
        order_index=2,
        estimated_minutes=20,
    )
    lesson3 = models.Lesson(
        course_id=course.id,
        title="Simple Equations",
        content_text=(
            "# Simple Equations\n\n"
            "An equation is a statement that two expressions are equal, like x + 3 = 7.\n\n"
            "### Solving for x\n"
            "To find x, do the same operation on both sides:\n\n"
            "x + 3 = 7\n"
            "x + 3 - 3 = 7 - 3\n"
            "x = 4\n\n"
            "### Practice Problems\n"
            "1. x + 5 = 12\n"
            "2. x - 2 = 9\n"
            "3. 3x = 15\n\n"
            "Solve each by isolating x on one side of the equation."
        ),
        video_url=None,
        order_index=3,
        estimated_minutes=15,
    )
    db.add_all([lesson1, lesson2, lesson3])
    db.flush()

    quiz = models.Quiz(lesson_id=lesson1.id, title="Fractions Quiz", pass_percentage=60.0)
    db.add(quiz)
    db.flush()

    questions = [
        models.Question(
            quiz_id=quiz.id,
            question_text="In the fraction 3/4, what is the numerator?",
            option_a="3", option_b="4", option_c="7", option_d="1",
            correct_option="a", points=1,
        ),
        models.Question(
            quiz_id=quiz.id,
            question_text="Which of these is a proper fraction?",
            option_a="5/4", option_b="4/4", option_c="3/8", option_d="9/2",
            correct_option="c", points=1,
        ),
        models.Question(
            quiz_id=quiz.id,
            question_text="If a roti is cut into 4 equal pieces and you eat 2, what fraction did you eat?",
            option_a="1/4", option_b="2/4", option_c="3/4", option_d="4/4",
            correct_option="b", points=1,
        ),
        models.Question(
            quiz_id=quiz.id,
            question_text="1 1/2 is an example of a:",
            option_a="Proper fraction", option_b="Improper fraction",
            option_c="Mixed number", option_d="Whole number",
            correct_option="c", points=1,
        ),
    ]
    db.add_all(questions)

    db.commit()
    print("Demo data created successfully!")
    print("\nLogin credentials:")
    print("  Teacher -> username: teacher1 / password: teacher123")
    print("  Students -> username: student1, student2, student3 / password: student123")

db.close()
